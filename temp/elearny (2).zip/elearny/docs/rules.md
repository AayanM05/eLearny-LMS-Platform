# eLearny — Rules Document (rules.md)

> Status: **v1.1 — living document, fresh-start reset.** Governs how code gets written across backend, web, and
> mobile — not what gets built (that's `prd.md`) or how it's structured
> (that's `architecture.md`). eLearny is a full-scale, production-grade LMS — **high-level and large-scale by design, not a demo or MVP**.
> Enforces mandatory High Content Density (§12), 100% Web & Mobile Feature & Content Parity within-tier (§13), a real Definition of Done (§13a), AI Development Double-Check Guardrails (§12/§13), and Zero Deprecation Warning Policy (§15). AI tools MUST double-check all work against these rules before completing any unit.

---

## 1. Backend Libraries — What to Use

| Concern | Library | Why |
|---|---|---|
| Web framework | Spring Boot 3.3.x (Web MVC) | Java 21 LTS compatibility & stable modern release |
| Data access | Spring Data JPA + Hibernate | Standard, avoids hand-written SQL for CRUD |
| DB migrations | Flyway | Versioned, committed schema changes — no hand-editing a live DB |
| DTO ↔ Entity mapping | MapStruct | Compile-time mapping, avoids hand-written boilerplate mappers and avoids leaking entities over the API |
| Boilerplate reduction | Lombok | `@Getter/@Setter/@Builder` — reduces noise, standard in Spring projects |
| Auth tokens | `io.jsonwebtoken` (jjwt) | JWT issuing/parsing |
| TOTP 2FA | `dev.samstevens.totp` | RFC 6238-compliant TOTP, no need to hand-roll crypto |
| Payments | Razorpay Java SDK (official) | Official SDK over hand-rolled HTTP calls |
| Object storage | AWS S3 SDK (v2) | Cloudflare R2 is S3-API-compatible — use the S3 SDK pointed at R2's endpoint, no separate R2-specific SDK needed |
| Email | `spring-boot-starter-mail` | Already decided (Gmail SMTP) |
| PDF generation | Apache PDFBox | Open-source, no licensing cost (iText's newer versions are AGPL/commercial — PDFBox avoids that ambiguity entirely) |
| API documentation | springdoc-openapi | Auto-generates OpenAPI spec from controllers — `packages/types` on the frontend can be generated from this instead of hand-kept in sync |
| Validation | `jakarta.validation` (Bean Validation) | Annotate DTOs (`@NotNull`, `@Size`, etc.), validate at the controller boundary, not deep in services |
| Testing | JUnit 5 + Mockito + Testcontainers | Testcontainers spins up a real Postgres for integration tests — no "works on H2, breaks on Postgres" surprises |
| Code execution sandbox | Judge0 (self-hosted, called via its REST API — not a Java library) | Isolated execution environment for Practice Hub |
| LLM client | Plain `WebClient` (Spring's reactive HTTP client) to Gemini/Groq's REST API | No need for a heavy SDK for a scoped, simple prompt/response call |

## 2. Backend Libraries — What to Avoid

- **Raw JDBC / hand-written SQL for CRUD** — Spring Data JPA covers this; hand-written SQL is reserved for genuinely complex queries (reporting, search) where JPA would be awkward, and even then goes through `@Query` on a repository, not scattered `JdbcTemplate` calls
- **Exposing JPA entities directly as API responses** — always map to a DTO. An entity has lazy-loading proxies, bidirectional relationships, and internal fields that will leak or break serialization if returned raw
- **Business logic in controllers** — controllers do request/response handling and delegate to services; a controller method should read like a table of contents, not contain `if` chains
- **`@Autowired` field injection** — use constructor injection everywhere (works better with `final` fields, makes dependencies testable and explicit)
- **Storing secrets (API keys, DB passwords) in code or committed config files** — environment variables only, injected via Docker Compose locally and the hosting platform's secret manager in production
- **Trusting any client-submitted value that determines money, time, or grades** — price, exam time limits, and quiz scores are always computed/validated server-side (already established in `architecture.md` flows) — this is a rule, not a one-off decision, and applies to every future feature too
- **`iText` for new PDF work** — recent versions carry AGPL/commercial licensing that conflicts with a free-tier, side-project-friendly stack; PDFBox is the actual choice (architecture.md listed both as options — this rule resolves that ambiguity)

---

## 3. Frontend (Next.js) Libraries — What to Use

| Concern | Library | Why |
|---|---|---|
| Data fetching / caching | TanStack Query (React Query) | Handles caching, refetching, loading/error states for our REST API — avoids hand-rolled `useEffect` fetch logic everywhere |
| Forms & validation | React Hook Form + Zod | Zod schemas can be shared conceptually with backend DTO shapes; RHF avoids re-render-heavy form state |
| UI components | shadcn/ui (on top of Tailwind, already decided) | Copy-in components, not a locked-in dependency — fits a project that will keep evolving its design |
| Animation | `motion` (Framer Motion's successor) | Already decided for engagement/gamification (PRD 3.10) |
| i18n | `next-intl` | Already decided (architecture.md 3.12) |
| Dark mode toggle | `next-themes` | Handles light/dark theme switching + persistence — pairs with the token architecture in `design.md` §2 (toggling just swaps which CSS variable set is active) |
| State that isn't server data | React Context / `useState`, or Zustand only if genuinely needed | Avoid reaching for a global state library before there's a real cross-page state problem to solve |

## 4. Frontend Libraries — What to Avoid

- **Redux (or any heavy global state library) by default** — most of this app's state is server state (courses, enrollment, progress), which TanStack Query already handles; adding Redux on top is usually solving a problem that doesn't exist yet
- **`fetch` calls scattered directly in components** — always go through `packages/api-client`, so auth headers, error handling, and base URL live in one place
- **`any` in TypeScript** — defeats the purpose of the shared `packages/types`; if a type is genuinely unknown, use `unknown` and narrow it
- **Inline `style={{}}` props** — Tailwind utility classes only, for consistency with the design system (`design.md` will govern the actual tokens)
- **Client components by default** — Next.js App Router: default to Server Components, opt into `"use client"` only where interactivity genuinely requires it (forms, animations, anything with `useState`/`useEffect`)

---

## 5. Mobile (Expo) Libraries — What to Use

| Concern | Library | Why |
|---|---|---|
| Navigation | Expo Router | File-based, mirrors the web's route-group structure conceptually |
| Data fetching | TanStack Query (same as web) | Same caching model, same `packages/api-client` |
| Styling | NativeWind v4 | Real Tailwind syntax on React Native — the mobile equivalent of web's Tailwind setup, so the same design vocabulary (spacing, color tokens) applies on both platforms even though the underlying mechanism differs (CSS on web, StyleSheet under the hood on mobile) |
| Fonts | `expo-font` + `@expo-google-fonts/inter` + `@expo-google-fonts/space-grotesk` | Expo's pre-hosted Google Fonts packages — no manual font-file management. See §14 for the mandatory global-loading pattern; this is what was missing and causing per-file font hacks |
| Animation | `react-native-reanimated` | Already decided — `motion` doesn't run on native |
| Notifications | `expo-notifications` | Standard Expo push notification handling |
| Secure token storage | `expo-secure-store` | JWTs must not sit in plain AsyncStorage |

---

## 6. Error Handling Conventions

- **Single global exception handler** (`@RestControllerAdvice`) on the backend — no controller should have its own ad hoc try/catch that formats an error response; exceptions are thrown and caught in exactly one place
- **Standard error response shape**, used everywhere:
```json
{
  "timestamp": "2026-09-08T10:15:00Z",
  "status": 400,
  "error": "VALIDATION_ERROR",
  "message": "Human-readable summary",
  "details": [ { "field": "email", "issue": "must be a valid email" } ],
  "path": "/api/v1/auth/register"
}
```
- **Never leak stack traces or internal exception messages to the client** — log the full exception server-side, return a safe, generic message + an error code the frontend can key off of
- **HTTP status codes used meaningfully**, not just 200/400/500 for everything: 401 (not authenticated), 403 (authenticated but not authorized — e.g. student hitting an instructor endpoint), 404 (resource doesn't exist), 409 (conflict — e.g. duplicate enrollment), 422 (validation failure), 429 (rate limit — relevant for the chatbot), 500 (genuine server fault)
- **Frontend**: TanStack Query's error state is the single place API errors surface — no separate ad hoc error-catching per component

---

## 7. Layer & Module Boundaries

- **Controller → Service → Repository, one direction only.** A controller never touches a repository directly; a repository never calls a service
- **DTOs cross layer boundaries at the API edge only** — internally, services can pass entities between each other within the same domain package, but anything crossing into another domain package or out over HTTP goes through a DTO
- **Cross-domain calls happen through a service's public methods, not by reaching into another domain's repository** — e.g. the `certificate` package asks `exam`'s service "did this attempt pass?", it doesn't query the `exam_attempts` table directly
- **Neither frontend ever calls a third-party service directly** (Razorpay, R2, Gemini/Groq, Judge0) — always through our own backend, per `architecture.md` section 1. This is a security boundary, not a style preference: it's the only way API keys stay server-side
- **`packages/api-client` is the only thing in the frontend that knows our API's base URL and auth header format** — no component or hook constructs a raw request

---

## 8. API Conventions

- **Versioned from day one**: all endpoints under `/api/v1/...` — this is what lets us change the API later without breaking whatever mobile app version is still in someone's hands (relevant once this reaches app stores and can't force-update everyone instantly)
- **REST resource naming**: plural nouns, no verbs in the path — `/api/v1/courses/{id}/lessons`, not `/api/v1/getCourseLessons`
- **Pagination**: standard `?page=0&size=20` query params, response includes `totalElements`, `totalPages`, `currentPage` — applied consistently on every list endpoint (courses, reviews, notifications, admin lists) rather than each one inventing its own shape
- **Auth header**: `Authorization: Bearer <jwt>` — no custom header schemes
- **Webhooks are signature-verified, always** — `/api/v1/webhooks/razorpay` (and any future webhook) rejects any request that doesn't pass signature verification before touching any business logic
- **Idempotency for payment-adjacent endpoints** — a retried webhook delivery (Razorpay can send the same event twice) must not create a duplicate enrollment or duplicate revenue record
- **CORS is explicitly configured, never wildcarded** — the dev profile allows `http://localhost:3000` (Next.js's actual default port, not 5173), the prod profile allows the deployed Vercel domain. `allowedOrigins("*")` is never used, even during development — see `deployment.md` §2.2

---

## 9. AI / Chatbot Rules

- **Never send personally identifiable information to the LLM provider** beyond what's strictly needed to answer the question — no raw email addresses, payment details, or other students' data in a prompt
- **System prompt scopes the bot to the platform** (FAQs, catalog, course-suggestion intent) — it does not become a general-purpose assistant; this keeps prompts short (cheaper, faster, more of the free quota available) and keeps answers relevant
- **Per-user rate limiting is enforced in our backend before the LLM call is made**, not after — checking quota after already spending it defeats the point
- **The rule-based course-suggestion path never calls the LLM** — if a query matches a suggestion intent, answer from the recommendation engine; the LLM is reserved for genuine free-text Q&A
- **Every LLM call is logged (prompt + response, minus any PII) server-side** for debugging and for tracking real usage against the free-tier quota — so approaching the limit is visible before users start seeing fallback messages
- **API key for the LLM provider lives only in backend environment config** — same rule as every other third-party secret

---

## 10. Code Reusability & Conciseness

- **Prefer a well-maintained library over hand-written logic** whenever one genuinely solves the problem — date/time formatting, form validation, HTTP retries, debouncing, etc. should come from a library (`date-fns`, Zod, TanStack Query's built-in retry), not be reimplemented. A hand-written 80-line date formatter is a bug source; `date-fns` isn't
- **This cuts both ways — it's not "always use the fewest lines," it's "don't duplicate solved problems."** A library call that hides genuinely important logic the team needs to control (e.g. our own grading logic, our own rate-limiting) stays hand-written on purpose; convenience utilities (formatting, animation easing curves, icon rendering) don't
- **Shared logic used in more than one place becomes a shared unit, not a copy-paste**: a repeated backend query pattern → a repository method; a repeated frontend UI pattern → a component in `packages/ui` or `frontend/web/components`; a repeated data-fetching pattern → a custom hook wrapping TanStack Query
- **Don't hand-roll a full page of boilerplate when a library component already covers it** — e.g. a data table with sorting/pagination/filtering should use an existing table component (shadcn/ui's `DataTable` pattern with TanStack Table underneath), not a hand-written `<table>` with manually managed sort state
- **The test for "should this be a library call":** would getting it wrong be a real bug (auth, payment amounts, grading) or a solved UI/utility problem (formatting, animation, icons)? Solved problems use libraries; anything where correctness is business-critical stays explicit and hand-written so it's reviewable

## 11. UI/UX — Modern, Professional, Not Generic

- **Icons/SVGs**: `lucide-react` (already implied by shadcn/ui's ecosystem) for standard icons — not hand-drawn inline SVGs for things that already exist as a well-maintained icon set. Custom illustrations (landing page graphics, empty states) can be custom SVGs, but interface icons shouldn't be reinvented per component
- **Animation**: `motion` on web (already decided, section 3), used deliberately — page transitions, hover/focus feedback, gamification moments (badge unlock, streak milestone, certificate reveal) — not animation for its own sake on every element, which reads as noisy rather than professional
- **Design isn't an afterthought bolted onto working code** — when building actual screens, the `frontend-design` skill governs visual decisions (typography, spacing, color, avoiding templated-looking defaults) and gets consulted before writing UI code, not after
- **`design.md`** is where the actual color palette, typography, and design tokens are decided — this section governs *how* we implement whatever `design.md` specifies, not what the specific colors/fonts are

---

## 12. Build High-Density, Production-Grade Pages (No Thin / Minimal Output)

**This is the single most important rule in this document for avoiding thin, disappointing AI-generated output.** AI tools often fall into the trap of creating minimal, 2-field placeholder screens. In eLearny, **minimal or thin pages are strictly prohibited.** Every page built must feel enterprise-grade, content-rich, visually polished, and production-ready.

- **Mandatory High Content Density**: Every page MUST feature multiple rich UI blocks, metric KPI cards, status badges, interactive tabbed panels, action toolbars, live field validation, and contextual helper widgets.
  - **Auth Pages (e.g., Register)**: Never build just email + password. A real registration screen contains: Full Name (first/last), Username with a live debounced availability check indicator (spinner → checkmark/cross + alternate username suggestions), Email, Phone number (optional), Password + Confirm password with a live requirement checklist badge list (min 8 chars, uppercase, lowercase, number, special character), password-match validation, role selection toggle (`STUDENT` / `INSTRUCTOR`), terms of service & privacy agreement checkbox (required), security reassurance banner, and support link.
  - **Dashboards (Student / Instructor / Admin / TA)**: Must feature a multi-widget grid: KPI metric cards with trend badges (total courses, active streak, certificates earned, total revenue), a "Continue Learning / Active Course" hero card with lesson progress bar and resume button, upcoming deadlines / scheduled office hours widget, recent activity feed, and recommendations carousel.
  - **Course Authoring**: Must include a multi-step workflow wizard (Basic Metadata, Target Audience & Prerequisites, Pricing & Coupons, Curriculum Builder with section/lesson drag-and-drop ordering, drip schedule inputs, R2 upload dropzones, and Quiz builder).
  - **List & Table Pages**: Must feature searching, multi-criteria filtering tabs, sorting dropdowns, pagination controls, status badges, and quick-action toolbars.
- **Multi-State UI Readiness**: Every page MUST explicitly render and handle all four lifecycle states: **Loading (skeleton shimmer)**, **Empty (informative graphic + CTA)**, **Error (retry button + user-friendly explanation)**, and **Populated Data**.
- **Self-Check Before Completion**: Would a user looking at this screen think it is as feature-rich and polished as Udemy, Coursera, Notion, or Stripe? If it looks sparse or minimal, it is **unfinished** and must be enriched with appropriate data cards, widgets, and secondary information blocks.

---

## 13. Strict 100% Web & Mobile Feature & Content Parity

**Every feature, user capability, form option, and workflow MUST exist on BOTH Web and Mobile with equal capability, within that feature's own delivery tier.** Mobile is NEVER a "lite", "view-only", or partial version of the web platform for anything in the same tier as what's currently being built. See `prd.md` §0 and `phases.md` v0.9 for the V1/V2 split — this rule does not require V2 features (Practice Hub/Judge0, TA surface, Instructor Leave/Office Hours, Excel export, SMS/push) to exist on mobile before V1 ships, since they don't exist on web yet either at that point.

- **Identical Functional Capabilities**: If an Instructor can create courses, build curriculums, set drip schedules, and view analytics on the Web (all V1), the Mobile app MUST provide the exact same creation and editing capabilities. Once V2 work starts (e.g. TA invites, Practice Hub code execution), the same rule applies to those features at that point.
- **UX Adaptation, Never Feature Omission**: The only difference between Web and Mobile is responsive UX layout design (e.g. desktop sidebars become bottom tab bars or drawer menus; desktop multi-column data tables become responsive stacked card lists). The underlying actions, inputs, data fields, and features are **100% identical**.
- **Simultaneous Milestone Deliveries**: Backend API + Next.js Web UI + Expo Mobile UI MUST be developed and verified together in the same checkpoint unit. A feature is incomplete until both Web and Mobile are proven working.

---

## 13a. Definition of Done — What "Checked" Actually Means

A phase-unit checkbox in `memory.md` may only be checked when all of the
following exist for that unit, not just when it's claimed done in prose:

1. **The exact verification command used** (e.g. `mvn test`, `npx tsc --noEmit`,
   a curl against a live endpoint) is written into the `memory.md` session-log
   entry for that unit.
2. **The actual output** (pass count, "0 errors", or equivalent) is quoted in
   that same entry — not just "verified" with no evidence.
3. **Both Web and Mobile evidence exists separately** for any unit that touches
   both, per §13 above — one platform's passing build does not imply the other's.

This rule exists because of a documented incident (see `memory.md`'s
2026-09-08 log entry): a prior session claimed all 13 phases were complete,
which turned out to include fabricated stats and broken pages. A prose claim
of "done" is not evidence; a command and its output are.

---

## 14. Mobile Custom Font Preloading & Zero-Fallback Infrastructure — Set Once Globally

**Why this rule exists:** React Native executes inside a JS engine (Hermes/JSC) on iOS and Android. It **cannot load Web CSS Google Fonts via `@import` links or `<link>` tags**. If custom fonts (`Inter` and `Space Grotesk`) are not explicitly bundled into the mobile asset package and preloaded before rendering, the app defaults to the generic system font (San Francisco on iOS, Roboto on Android) or renders unstyled text.

**Mandatory Mobile Font Bundling Architecture:**

1. **Package Dependencies (`frontend/mobile/package.json`)**:
   - Install `@expo-google-fonts/inter` (`Inter_400Regular`, `Inter_500Medium`, `Inter_600SemiBold`, `Inter_700Bold`) and `@expo-google-fonts/space-grotesk` (`SpaceGrotesk_700Bold`) as explicit dependencies.
   - Alternatively, bundle local `.ttf`/`.otf` font files in `frontend/mobile/assets/fonts/` loaded via `expo-font`.

2. **Splash Screen Gating & Font Preloading (`frontend/mobile/app/_layout.tsx`)**:
   - In the root layout, prevent native splash screen auto-hiding until custom fonts finish loading:
     ```tsx
     import { useFonts, Inter_400Regular, Inter_500Medium, Inter_600SemiBold, Inter_700Bold } from '@expo-google-fonts/inter';
     import { SpaceGrotesk_700Bold } from '@expo-google-fonts/space-grotesk';
     import * as SplashScreen from 'expo-splash-screen';

     SplashScreen.preventAutoHideAsync();

     export default function RootLayout() {
       const [fontsLoaded, fontError] = useFonts({
         Inter_400Regular,
         Inter_500Medium,
         Inter_600SemiBold,
         Inter_700Bold,
         SpaceGrotesk_700Bold,
       });

       useEffect(() => {
         if (fontsLoaded || fontError) {
           SplashScreen.hideAsync();
         }
       }, [fontsLoaded, fontError]);

       if (!fontsLoaded && !fontError) {
         return null; // Keeps splash screen visible; zero unstyled text flickering!
       }

       // 3. Override React Native default font ONCE globally
       // @ts-ignore
       Text.defaultProps = Text.defaultProps || {};
       // @ts-ignore
       Text.defaultProps.style = { fontFamily: 'Inter_400Regular' };
       // @ts-ignore
       TextInput.defaultProps = TextInput.defaultProps || {};
       // @ts-ignore
       TextInput.defaultProps.style = { fontFamily: 'Inter_400Regular' };

       return <Stack ... />;
     }
     ```

3. **Global Font Application**:
   - Every `Text` and `TextInput` in the mobile app inherits `Inter_400Regular` automatically.
   - Headings that require Space Grotesk use a single shared `<Heading>` component in `frontend/mobile/components/common/Heading.tsx` that sets `fontFamily: 'SpaceGrotesk_700Bold'`.
   - **Per-file `fontFamily` hacks are strictly forbidden.**

---

## 15. Zero Deprecation Warning Policy — Modern Package Versions Only

**All libraries, tools, and dependencies installed across root, web, mobile, shared packages, and Java backend must use modern, active, non-deprecated stable release versions.**

- **No Deprecated Packages**: Do not install packages or SDK versions that emit deprecation warnings during `npm install`, `npx`, `expo start`, or `mvn compile`.
- **Node & NPM Tooling**: Use current LTS versions of Node.js and modern NPM package managers.
- **Expo & React Native**: Mobile applications use the latest stable Expo SDK release (`npx create-expo-app@latest` — Expo SDK 52+ / latest stable) and modern React Native with NativeWind v4.
- **Spring Boot**: Backend uses Spring Boot 3.3.x targeting Java 21 LTS.

---

## 17. Brand Logo & Asset Architecture (Web + Mobile)

**Master Brand Assets (`logo/` Directory Structure)**:

1. **Master Directory Structure (`logo/`)**:
   - `hr-logo.png`: Horizontal Light Mode logo with white background.
   - `hr-logo-bgr.png`: Horizontal Light Mode logo without background (transparent).
   - `hr-logo-dark.png`: Horizontal Dark Mode logo with dark background (`#1E2022`).
   - `hr-logo-dark-bgr.png`: Horizontal Dark Mode logo without background (transparent).
   - `logo-icon.png`: Square 1:1 icon mark (Terracotta student avatar + graduation cap).
   - `favicon/`: Extracted Web Favicon Suite (`favicon.ico`, `favicon.svg`, `favicon-96x96.png`, `apple-touch-icon.png`, `site.webmanifest`).

2. **Web Branding Integration (`frontend/web/public/assets/branding/`)**:
   - Favicon assets copied to `frontend/web/public/`.
   - `BrandLogo` component auto-detects `next-themes` (`light` vs. `dark`) and switches between `hr-logo-bgr.png` and `hr-logo-dark-bgr.png`.

3. **Mobile Splash Screen & App Icon (`frontend/mobile/assets/branding/`)**:
   - **Centered Horizontal Logo Splash Screen**: Native mobile splash screen renders the **centered horizontal logo** (`hr-logo-bgr.png` for Light theme, `hr-logo-dark-bgr.png` for Dark theme) on `#FFFFFF` or `#0F172A` background according to the active theme chosen in the app.
   - `logo-icon.png` is assigned as the native app launcher icon in Expo `app.json`.

---

---

## 18. Mandatory Workspace Customization Skills Integration

Whenever creating or modifying web/mobile UI components, screens, layout structures, micro-interactions, or styling design tokens, AI tools MUST view and adhere to the project's 6 custom workspace skills in `.agents/skills/`:

1. **[`taste-design-system`](file:///a:/Java%20SpringBoot%20Projects/eLearny%20-%20LMS/.agents/skills/taste-design-system/SKILL.md)**: Governs visual excellence, Terracotta Orange (`#D96B43` / `HSL 17° 66% 56%`) token hierarchy, glassmorphism standards, and typography rules.
2. **[`mobile-app-uiux-benchmarks`](file:///a:/Java%20SpringBoot%20Projects/eLearny%20-%20LMS/.agents/skills/mobile-app-uiux-benchmarks/SKILL.md)**: Governs flagship mobile layout structures derived from Zomato, Swiggy, Instagram, DigiLocker, Duolingo, and Airbnb — including Floating Action Docks, Collapsible Location Headers, Verified Certificate Badges, and Tactile 3D Buttons (`border-b-5`).
3. **[`gsap-animation-uiux`](file:///a:/Java%20SpringBoot%20Projects/eLearny%20-%20LMS/.agents/skills/gsap-animation-uiux/SKILL.md)**: Governs Next.js GSAP 3 web animations (`useGSAP`, `ScrollTrigger`, `contextSafe` event handlers).
4. **[`reanimated-mobile-gestures`](file:///a:/Java%20SpringBoot%20Projects/eLearny%20-%20LMS/.agents/skills/reanimated-mobile-gestures/SKILL.md)**: Governs Expo React Native Reanimated 3 hardware-accelerated 60fps native gestures, spring physics, and pan gestures.
5. **[`21st-dev-components`](file:///a:/Java%20SpringBoot%20Projects/eLearny%20-%20LMS/.agents/skills/21st-dev-components/SKILL.md)**: Governs sourcing, installing, and customizing modern React component blocks via the `21st-dev` MCP server.
6. **[`shadcn-ui-components`](file:///a:/Java%20SpringBoot%20Projects/eLearny%20-%20LMS/.agents/skills/shadcn-ui-components/SKILL.md)**: Governs adding and extending Shadcn UI primitives (Radix UI + Tailwind CSS) via the `shadcn` MCP server.

---

## 16. Change Log
- **v1.1** — Added §18 ("Mandatory Workspace Customization Skills Integration") mandating that AI tools consult all 6 workspace skills in `.agents/skills/` before executing UI, UX, animation, or mobile layout tasks.
- **v0.1** — Initial rules drafted covering backend/frontend/mobile library
  choices (with reasoning, including resolving the PDFBox vs. iText
  ambiguity left open in `architecture.md`), error handling conventions,
  layer/module boundaries, API conventions, and AI/chatbot-specific rules.
- **v0.2** — Added code reusability/conciseness guidance (prefer libraries
  over hand-rolled solved-problems, shared logic becomes shared units, with
  an explicit carve-out for business-critical logic that should stay
  hand-written and reviewable) and a UI/UX section (icon library, deliberate
  animation use, `frontend-design` skill governing visual decisions).
- **v0.3** — Consistency pass: fixed a section-numbering gap (9 jumped to
  11 with no 10 — renumbered to 10/11/12), added `next-themes` to the
  frontend library table (it was referenced in `design.md` but never
  tracked here), and removed a stale "design.md is the next doc" reference
  now that `design.md` already exists.
- **v0.4** — Added an explicit CORS rule (dev allows `localhost:3000`,
  never a wildcard) after drafting `deployment.md`, which requires this to
  actually work locally.
- **v0.5** — Path fix: frontend component references now correctly point
  to `frontend/web/components` (folder structure is `frontend/web` +
  `frontend/mobile`, not flat top-level folders).
- **v0.6** — Added §12: "Build the Complete Page, Not the Minimum Literal
  Reading" — the standing rule that `pages.md`/`prd.md` describe scope,
  not an exhaustive field-by-field spec, and filling that gap with real
  production judgment (not the literal minimum) is expected on every
  page, not just the ones called out with extra detail.
- **v0.7** — Added §13: "Full Parity Is Mandatory — No Partial-Platform
  Ships" — a feature isn't done if it only shipped on one frontend
  platform. Also changed `memory.md`'s checklist convention to split
  Web/Mobile into separate checkboxes per phase item so partial
  completion is visible instead of hidden inside one combined box.
- **v0.8** — Fixed a real architectural gap: no styling solution or font
  mechanism was ever defined for mobile, which is why per-file font
  hacks kept happening. Added NativeWind as mobile's styling solution
  (§5) and §14, a mandatory global-font-loading pattern (`expo-font` +
  a one-time `Text.defaultProps` override in the root layout) so the
  font gets set once, globally, never per-file again.
- **v0.9** — Added §15: Zero Deprecation Warning Policy — mandated current
  stable versions across all NPM packages, Expo SDK 51+, Next.js 14.2+, and
  Spring Boot 3.3.x (Java 21).
- **v1.0** — Expanded §12 ("Build High-Density, Production-Grade Pages — No Thin / Minimal Output") to strictly forbid 2-field placeholder UI, requiring multi-widget cards, live validation, status badges, and multi-state rendering. Expanded §13 ("Strict 100% Web & Mobile Feature & Content Parity") to mandate that every feature and creation workflow on Web exists with equal capability on Mobile.
- **v1.1** — **Fresh-start reset, aligned to `prd.md` v1.0 / `phases.md` v0.9's V1/V2 split.** Scoped §13's parity rule to "within a feature's own delivery tier" — it never required V2 features to exist on mobile before they exist on web either. Added new §13a, "Definition of Done — What 'Checked' Actually Means," requiring the exact verification command and its actual output to be logged in `memory.md` before any checkbox is checked, plus separate Web/Mobile evidence — a direct, concrete fix for the false "all 13 phases complete" incident, replacing "trust the prose claim" with "show the command output."

