package com.elearny.common;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class HealthController {

    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> checkHealth() {
        Map<String, Object> healthInfo = Map.of(
            "status", "UP",
            "service", "elearny-backend",
            "version", "0.1.0",
            "timestamp", Instant.now().toString()
        );
        return ResponseEntity.ok(healthInfo);
    }
}
