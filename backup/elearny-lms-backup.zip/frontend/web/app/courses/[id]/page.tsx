'use client';

import React, { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { api } from '@/lib/api';
import {
  BookOpen,
  Clock,
  Award,
  PlayCircle,
  CheckCircle2,
  Lock,
  Star,
  Users,
  Shield,
  ArrowLeft,
  ChevronDown,
  ChevronRight,
  Share2,
  Bookmark,
  Sparkles,
  FileText,
  Video,
  X
} from 'lucide-react';

interface Lesson {
  id: string;
  title: string;
  durationSeconds: number;
  isPreview: boolean;
  dripDelayDays: number;
  contentType: string;
}

interface Section {
  id: string;
  title: string;
  displayOrder: number;
  lessons: Lesson[];
}

interface CourseDetail {
  id: string;
  title: string;
  subtitle?: string;
  description?: string;
  category: string;
  level: string;
  price: number;
  thumbnailUrl?: string;
  instructorName?: string;
  instructorBio?: string;
  status: string;
  sections: Section[];
}

export default function CourseDetailPage() {
  const params = useParams();
  const router = useRouter();
  const courseId = params?.id as string;

  const [course, setCourse] = useState<CourseDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({});
  const [activePreviewLesson, setActivePreviewLesson] = useState<Lesson | null>(null);
  const [isWishlisted, setIsWishlisted] = useState(false);

  useEffect(() => {
    fetchCourseDetail();
  }, [courseId]);

  const fetchCourseDetail = async () => {
    setLoading(true);
    try {
      // Fetch public course data
      const data: any = await api.fetch(`/courses/${courseId}`);
      setCourse(data);
      if (data?.sections?.length > 0) {
        const initialOpen: Record<string, boolean> = {};
        data.sections.forEach((sec: Section, index: number) => {
          initialOpen[sec.id] = index === 0; // open first section by default
        });
        setOpenSections(initialOpen);
      }
    } catch (err) {
      // Fallback mock data if API endpoint returns mock or offline
      setCourse({
        id: courseId || 'demo-1',
        title: 'Master Full-Stack Web Development with Spring Boot 3 & Next.js 14',
        subtitle: 'Build enterprise-grade software platforms from scratch with reactive Java backend, Next.js, and Expo mobile.',
        description: 'This comprehensive course teaches you how to design, architect, and deploy production software platforms. You will cover RESTful API design, Spring Security with JWT & TOTP 2FA, Flyway migrations, database indexing, and frontends built with Next.js App Router and React Native Expo.',
        category: 'Software Engineering',
        level: 'INTERMEDIATE',
        price: 49.99,
        thumbnailUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?q=80&w=800',
        instructorName: 'Dr. Sarah Jenkins',
        instructorBio: 'Senior Principal Engineer & Author with 15+ years building distributed backend systems and mobile architectures.',
        status: 'PUBLISHED',
        sections: [
          {
            id: 'sec-1',
            title: 'Section 1: Monorepo Architecture & Spring Boot 3 Baseline',
            displayOrder: 1,
            lessons: [
              { id: 'les-1', title: 'Course Architecture Overview & Monorepo Setup', durationSeconds: 620, isPreview: true, dripDelayDays: 0, contentType: 'VIDEO' },
              { id: 'les-2', title: 'Spring Boot 3 Web MVC Dependencies & Flyway Baseline', durationSeconds: 840, isPreview: true, dripDelayDays: 0, contentType: 'VIDEO' },
              { id: 'les-3', title: 'Domain Driven Package Structure & Exception Handler', durationSeconds: 910, isPreview: false, dripDelayDays: 0, contentType: 'VIDEO' },
            ],
          },
          {
            id: 'sec-2',
            title: 'Section 2: Authentication, Security & RBAC',
            displayOrder: 2,
            lessons: [
              { id: 'les-4', title: 'JWT Access & Refresh Token Architecture', durationSeconds: 1100, isPreview: false, dripDelayDays: 1, contentType: 'VIDEO' },
              { id: 'les-5', title: 'TOTP 2FA Authentication Implementation', durationSeconds: 780, isPreview: false, dripDelayDays: 2, contentType: 'VIDEO' },
            ],
          },
        ],
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleSection = (sectionId: string) => {
    setOpenSections((prev) => ({ ...prev, [sectionId]: !prev[sectionId] }));
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    return `${mins} mins`;
  };

  if (loading) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center bg-background text-foreground">
        <div className="flex items-center space-x-3">
          <div className="h-5 w-5 rounded-full border-2 border-primary border-t-transparent animate-spin" />
          <span className="text-sm font-medium">Loading Course Details...</span>
        </div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="max-w-4xl mx-auto py-16 text-center space-y-4">
        <h2 className="text-2xl font-display font-bold">Course Not Found</h2>
        <p className="text-sm text-muted-foreground">The requested course detail is not available or has been unlisted.</p>
        <Link href="/browse" className="inline-flex items-center space-x-2 text-primary font-semibold hover:underline">
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Browse</span>
        </Link>
      </div>
    );
  }

  const totalLessons = course.sections.reduce((acc, sec) => acc + sec.lessons.length, 0);
  const totalDuration = course.sections.reduce(
    (acc, sec) => acc + sec.lessons.reduce((lAcc, les) => lAcc + les.durationSeconds, 0),
    0
  );

  return (
    <div className="w-full bg-background text-foreground">
      {/* 1. Hero Banner */}
      <section className="w-full bg-muted/30 text-foreground border-b border-border py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
            
            {/* Main Info Header */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center space-x-2 text-xs font-semibold uppercase tracking-wider text-primary">
                <Link href="/browse" className="hover:underline flex items-center space-x-1">
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Browse</span>
                </Link>
                <span>/</span>
                <span className="text-muted-foreground">{course.category}</span>
              </div>

              <h1 className="text-3xl sm:text-4xl font-display font-bold tracking-tight text-foreground leading-tight">
                {course.title}
              </h1>

              {course.subtitle && (
                <p className="text-base sm:text-lg text-muted-foreground font-normal leading-relaxed">
                  {course.subtitle}
                </p>
              )}

              {/* Meta Badges */}
              <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-muted-foreground pt-2">
                <div className="flex items-center space-x-1 text-amber-500 font-semibold">
                  <Star className="w-4 h-4 fill-amber-500" />
                  <span>4.9 (128 reviews)</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Users className="w-4 h-4 text-primary" />
                  <span>1,420 Students Enrolled</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Award className="w-4 h-4 text-emerald-600" />
                  <span>Level: {course.level}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span>{formatDuration(totalDuration)} Total Content</span>
                </div>
              </div>

              <div className="pt-2 text-xs text-muted-foreground flex items-center space-x-2">
                <span>Created by</span>
                <span className="font-semibold text-foreground">{course.instructorName || 'Dr. Sarah Jenkins'}</span>
              </div>
            </div>

            {/* Sidebar Pricing & Enrollment Card */}
            <div className="lg:col-span-1 bg-card text-card-foreground border border-border rounded-lg shadow-xl p-6 space-y-6 sticky top-24">
              {course.thumbnailUrl && (
                <div className="relative aspect-video rounded-sm overflow-hidden bg-slate-900 border border-border">
                  <img src={course.thumbnailUrl} alt={course.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-slate-950/40 flex items-center justify-center">
                    <button
                      onClick={() => {
                        const previewLesson = course.sections[0]?.lessons.find((l) => l.isPreview);
                        if (previewLesson) setActivePreviewLesson(previewLesson);
                      }}
                      className="p-3 bg-white/90 text-slate-900 rounded-full hover:scale-105 transition-transform shadow-lg"
                      title="Preview Course"
                    >
                      <PlayCircle className="w-8 h-8 text-primary" />
                    </button>
                  </div>
                </div>
              )}

              <div className="flex items-baseline justify-between border-b border-border pb-4">
                <div>
                  <span className="text-3xl font-display font-bold text-foreground">
                    ${course.price.toFixed(2)}
                  </span>
                  <span className="text-xs text-muted-foreground ml-2 line-through">
                    ${(course.price * 1.5).toFixed(2)}
                  </span>
                </div>
                <span className="text-xs font-semibold px-2 py-0.5 bg-emerald-500/10 text-emerald-600 border border-emerald-500/20 rounded-sm">
                  33% OFF
                </span>
              </div>

              <div className="space-y-3">
                <button
                  onClick={() => router.push(`/checkout/${course.id}`)}
                  className="w-full py-3 bg-primary text-primary-foreground font-semibold rounded-sm hover:opacity-90 transition-opacity shadow-md text-sm flex items-center justify-center space-x-2"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Enroll in Course Now</span>
                </button>

                <button
                  onClick={() => setIsWishlisted(!isWishlisted)}
                  className={`w-full py-2.5 border border-border font-semibold text-xs rounded-sm transition-colors flex items-center justify-center space-x-2 ${
                    isWishlisted ? 'bg-primary/10 text-primary border-primary/30' : 'bg-background hover:bg-muted text-foreground'
                  }`}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${isWishlisted ? 'fill-primary' : ''}`} />
                  <span>{isWishlisted ? 'Saved in Wishlist' : 'Add to Wishlist'}</span>
                </button>
              </div>

              <div className="space-y-2 text-xs text-muted-foreground border-t border-border pt-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                  <span>Full Lifetime Access to all modules</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Award className="w-4 h-4 text-primary shrink-0" />
                  <span>Verifiable Certificate of Completion</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-violet-500 shrink-0" />
                  <span>30-Day Money-Back Guarantee</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Main Content Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-10">
          
          {/* What You'll Learn */}
          <div className="p-6 border border-border rounded-lg bg-card space-y-4">
            <h2 className="text-xl font-display font-bold flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-primary" />
              <span>What You Will Learn</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                <span>Architect scalable Spring Boot 3 microservices and REST APIs</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                <span>Implement JWT Tokens, TOTP 2FA, and RBAC role security</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                <span>Build responsive Next.js App Router & Expo React Native frontends</span>
              </div>
              <div className="flex items-start space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                <span>Manage database migrations with Flyway & PostgreSQL</span>
              </div>
            </div>
          </div>

          {/* Course Curriculum */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-display font-bold">Course Curriculum</h2>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {course.sections.length} Sections • {totalLessons} Lessons • {formatDuration(totalDuration)} total length
                </p>
              </div>
            </div>

            <div className="border border-border rounded-lg overflow-hidden bg-card divide-y divide-border">
              {course.sections.map((section, idx) => {
                const isOpen = openSections[section.id];
                return (
                  <div key={section.id} className="bg-card">
                    <button
                      onClick={() => toggleSection(section.id)}
                      className="w-full px-5 py-4 flex items-center justify-between hover:bg-muted/50 transition-colors text-left"
                    >
                      <div className="flex items-center space-x-3">
                        {isOpen ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
                        <span className="font-display font-bold text-sm text-foreground">
                          {section.title}
                        </span>
                      </div>
                      <span className="text-xs text-muted-foreground font-medium">
                        {section.lessons.length} lessons
                      </span>
                    </button>

                    {isOpen && (
                      <div className="bg-muted/20 px-5 py-2 divide-y divide-border/60">
                        {section.lessons.map((lesson) => (
                          <div key={lesson.id} className="py-2.5 flex items-center justify-between text-xs">
                            <div className="flex items-center space-x-2.5">
                              <Video className="w-4 h-4 text-muted-foreground shrink-0" />
                              <span className="font-medium text-foreground">{lesson.title}</span>
                              {lesson.isPreview && (
                                <button
                                  onClick={() => setActivePreviewLesson(lesson)}
                                  className="px-2 py-0.5 text-[10px] font-semibold bg-primary/10 text-primary border border-primary/20 rounded-sm hover:underline"
                                >
                                  Free Preview
                                </button>
                              )}
                            </div>
                            <div className="flex items-center space-x-3 text-muted-foreground">
                              {lesson.dripDelayDays > 0 && (
                                <span className="text-[10px] bg-amber-500/10 text-amber-600 border border-amber-500/20 px-1.5 py-0.5 rounded-sm">
                                  Unlocks Day {lesson.dripDelayDays}
                                </span>
                              )}
                              <span>{formatDuration(lesson.durationSeconds)}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Instructor Bio */}
          <div className="p-6 border border-border rounded-lg bg-card space-y-4">
            <h2 className="text-xl font-display font-bold">About the Instructor</h2>
            <div className="flex items-start space-x-4">
              <div className="h-12 w-12 rounded-sm bg-primary/10 text-primary font-bold text-lg flex items-center justify-center shrink-0">
                {course.instructorName ? course.instructorName[0] : 'S'}
              </div>
              <div className="space-y-1">
                <h3 className="font-display font-bold text-base">{course.instructorName || 'Dr. Sarah Jenkins'}</h3>
                <p className="text-xs text-muted-foreground">Principal Software Architect & Lead Educator</p>
                <p className="text-xs text-foreground/90 leading-relaxed pt-2">
                  {course.instructorBio || 'Passionate about engineering systems at scale and mentoring developers in enterprise Spring Boot and React architectures.'}
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Free Preview Video Modal */}
      {activePreviewLesson && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-lg max-w-2xl w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <div className="flex items-center space-x-2">
                <PlayCircle className="w-5 h-5 text-primary" />
                <span className="font-display font-bold text-base">Free Lesson Preview</span>
              </div>
              <button
                onClick={() => setActivePreviewLesson(null)}
                className="p-1 text-muted-foreground hover:text-foreground rounded-sm"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="aspect-video bg-slate-900 rounded-sm border border-border flex items-center justify-center">
              <div className="text-center space-y-2 p-4">
                <PlayCircle className="w-12 h-12 text-primary mx-auto opacity-90 animate-pulse" />
                <p className="font-display font-bold text-sm text-white">{activePreviewLesson.title}</p>
                <p className="text-xs text-slate-400">Sample Stream Preview • Signed R2 Media Player</p>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-muted-foreground pt-2">
              <span>Duration: {formatDuration(activePreviewLesson.durationSeconds)}</span>
              <button
                onClick={() => {
                  setActivePreviewLesson(null);
                  router.push(`/checkout/${course.id}`);
                }}
                className="px-4 py-2 bg-primary text-primary-foreground font-semibold rounded-sm hover:opacity-90"
              >
                Enroll to Access Full Course
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
