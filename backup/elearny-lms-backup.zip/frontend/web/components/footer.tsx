import React from 'react';
import Link from 'next/link';
import { BookOpen } from 'lucide-react';

export function Footer() {
  return (
    <footer className="w-full border-t border-border bg-muted/30 text-muted-foreground mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand Info */}
          <div className="space-y-4 md:col-span-1">
            <Link href="/" className="flex items-center space-x-2">
              <div className="bg-primary text-primary-foreground p-1.5 rounded-sm">
                <BookOpen className="h-5 w-5" />
              </div>
              <span className="font-display font-bold text-xl tracking-tight text-foreground">
                eLearny
              </span>
            </Link>
            <p className="text-sm leading-relaxed text-muted-foreground">
              Enterprise-grade Learning Management System with verified certificates, interactive coding sandboxes, and full mobile parity.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-3 font-display">
              Platform
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/browse" className="hover:text-primary transition-colors">
                  Browse Courses
                </Link>
              </li>
              <li>
                <Link href="/practice" className="hover:text-primary transition-colors">
                  Practice Hub
                </Link>
              </li>
              <li>
                <Link href="/community" className="hover:text-primary transition-colors">
                  Community Q&A
                </Link>
              </li>
              <li>
                <Link href="/apply-instructor" className="hover:text-primary transition-colors">
                  Teach on eLearny
                </Link>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-3 font-display">
              Categories
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/browse?category=development" className="hover:text-primary transition-colors">
                  Software Engineering
                </Link>
              </li>
              <li>
                <Link href="/browse?category=business" className="hover:text-primary transition-colors">
                  Business & Analytics
                </Link>
              </li>
              <li>
                <Link href="/browse?category=design" className="hover:text-primary transition-colors">
                  UI/UX & Graphic Design
                </Link>
              </li>
              <li>
                <Link href="/browse?category=cloud" className="hover:text-primary transition-colors">
                  Cloud & DevOps
                </Link>
              </li>
            </ul>
          </div>

          {/* Trust & Legal */}
          <div>
            <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-3 font-display">
              Governance & Legal
            </h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/terms" className="hover:text-primary transition-colors">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-primary transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/certificates/verify" className="hover:text-primary transition-colors">
                  Verify Certificate
                </Link>
              </li>
              <li>
                <Link href="/support" className="hover:text-primary transition-colors">
                  Help Center
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-8 flex flex-col sm:flex-row items-center justify-between text-xs">
          <p>© {new Date().getFullYear()} eLearny Platform. All rights reserved.</p>
          <div className="flex items-center space-x-4 mt-4 sm:mt-0">
            <span className="inline-flex items-center space-x-1.5">
              <span className="h-2 w-2 rounded-full bg-emerald-500" />
              <span>All Systems Operational</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
