'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useAuth } from '../lib/auth';
import {
  BookOpen,
  Search,
  Bell,
  User,
  LogOut,
  LayoutDashboard,
  PlusCircle,
  Shield,
  Menu,
  X,
  Bookmark,
  Award
} from 'lucide-react';

export function Navbar() {
  const { user, logout } = useAuth();
  const pathname = usePathname();
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/browse?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const getDashboardLink = () => {
    if (!user) return '/login';
    switch (user.role) {
      case 'ADMIN':
        return '/admin/dashboard';
      case 'INSTRUCTOR':
        return '/courses';
      default:
        return '/dashboard';
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Left: Brand Logo & Navigation */}
          <div className="flex items-center space-x-8">
            <Link href="/" className="flex items-center space-x-2">
              <div className="bg-primary text-primary-foreground p-1.5 rounded-sm">
                <BookOpen className="h-5 w-5" />
              </div>
              <span className="font-display font-bold text-xl tracking-tight">
                eLearny
              </span>
            </Link>

            {/* Desktop Navigation Links */}
            <nav className="hidden md:flex items-center space-x-6 text-sm font-medium">
              <Link
                href="/browse"
                className={`transition-colors hover:text-primary ${
                  pathname === '/browse' ? 'text-primary font-semibold' : 'text-muted-foreground'
                }`}
              >
                Browse Courses
              </Link>
              {user?.role === 'STUDENT' && (
                <>
                  <Link
                    href="/dashboard"
                    className={`transition-colors hover:text-primary ${
                      pathname === '/dashboard' ? 'text-primary font-semibold' : 'text-muted-foreground'
                    }`}
                  >
                    My Learning
                  </Link>
                  <Link
                    href="/wishlist"
                    className={`transition-colors hover:text-primary ${
                      pathname === '/wishlist' ? 'text-primary font-semibold' : 'text-muted-foreground'
                    }`}
                  >
                    Wishlist
                  </Link>
                </>
              )}
              {user?.role === 'INSTRUCTOR' && (
                <>
                  <Link
                    href="/courses"
                    className={`transition-colors hover:text-primary ${
                      pathname?.startsWith('/courses') ? 'text-primary font-semibold' : 'text-muted-foreground'
                    }`}
                  >
                    My Courses
                  </Link>
                  <Link
                    href="/courses/create"
                    className="inline-flex items-center space-x-1.5 text-primary font-semibold hover:opacity-80"
                  >
                    <PlusCircle className="h-4 w-4" />
                    <span>Create Course</span>
                  </Link>
                </>
              )}
              {user?.role === 'ADMIN' && (
                <Link
                  href="/instructor-applications"
                  className={`transition-colors hover:text-primary ${
                    pathname?.startsWith('/instructor-applications') ? 'text-primary font-semibold' : 'text-muted-foreground'
                  }`}
                >
                  Admin Approvals
                </Link>
              )}
            </nav>
          </div>

          {/* Center: Search Bar */}
          <form onSubmit={handleSearch} className="hidden lg:flex items-center flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search courses, topics, instructors..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-1.5 text-sm bg-muted/50 border border-border rounded-sm focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-colors"
              />
            </div>
          </form>

          {/* Right: Auth / Profile Controls */}
          <div className="flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-3">
                {/* Notifications Bell */}
                <Link
                  href="/notifications"
                  className="p-2 text-muted-foreground hover:text-foreground relative rounded-sm transition-colors"
                  aria-label="Notifications"
                >
                  <Bell className="h-5 w-5" />
                  <span className="absolute top-1 right-1 h-2 w-2 bg-primary rounded-full" />
                </Link>

                {/* Role Badge */}
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-sm text-xs font-semibold uppercase tracking-wider bg-muted text-muted-foreground border border-border">
                  {user.role}
                </span>

                {/* User Dropdown Toggle */}
                <div className="relative">
                  <button
                    onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                    className="flex items-center space-x-2 p-1 border border-border rounded-sm hover:bg-muted transition-colors focus:outline-none"
                  >
                    <div className="h-8 w-8 rounded-sm bg-primary/10 text-primary font-bold flex items-center justify-center text-sm">
                      {user.fullName ? user.fullName[0].toUpperCase() : 'U'}
                    </div>
                    <span className="hidden md:inline-block text-sm font-medium max-w-[100px] truncate">
                      {user.fullName}
                    </span>
                  </button>

                  {/* Dropdown Menu */}
                  {userDropdownOpen && (
                    <div
                      className="absolute right-0 mt-2 w-56 bg-background border border-border rounded-sm shadow-lg py-1 z-50 animate-in fade-in-80 slide-in-from-top-2"
                      onMouseLeave={() => setUserDropdownOpen(false)}
                    >
                      <div className="px-4 py-2 border-b border-border">
                        <p className="text-sm font-semibold truncate">{user.fullName}</p>
                        <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                      </div>

                      <Link
                        href={getDashboardLink()}
                        onClick={() => setUserDropdownOpen(false)}
                        className="flex items-center space-x-2 px-4 py-2 text-sm text-foreground hover:bg-muted transition-colors"
                      >
                        <LayoutDashboard className="h-4 w-4" />
                        <span>Dashboard</span>
                      </Link>

                      {user.role === 'STUDENT' && (
                        <>
                          <Link
                            href="/certificates"
                            onClick={() => setUserDropdownOpen(false)}
                            className="flex items-center space-x-2 px-4 py-2 text-sm text-foreground hover:bg-muted transition-colors"
                          >
                            <Award className="h-4 w-4" />
                            <span>My Certificates</span>
                          </Link>
                          <Link
                            href="/apply-instructor"
                            onClick={() => setUserDropdownOpen(false)}
                            className="flex items-center space-x-2 px-4 py-2 text-sm text-foreground hover:bg-muted transition-colors"
                          >
                            <Shield className="h-4 w-4" />
                            <span>Become an Instructor</span>
                          </Link>
                        </>
                      )}

                      <div className="border-t border-border mt-1 pt-1">
                        <button
                          onClick={() => {
                            setUserDropdownOpen(false);
                            logout();
                            router.push('/login');
                          }}
                          className="w-full flex items-center space-x-2 px-4 py-2 text-sm text-destructive hover:bg-destructive/10 transition-colors"
                        >
                          <LogOut className="h-4 w-4" />
                          <span>Sign Out</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <Link
                  href="/login"
                  className="px-4 py-2 text-sm font-medium text-foreground hover:text-primary transition-colors"
                >
                  Log In
                </Link>
                <Link
                  href="/register"
                  className="px-4 py-2 text-sm font-medium bg-primary text-primary-foreground rounded-sm hover:opacity-90 transition-opacity"
                >
                  Get Started
                </Link>
              </div>
            )}

            {/* Mobile Hamburger Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-muted-foreground hover:text-foreground"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-border bg-background px-4 pt-2 pb-4 space-y-3">
          <form onSubmit={handleSearch} className="relative mt-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search courses..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-sm bg-muted/50 border border-border rounded-sm"
            />
          </form>

          <nav className="space-y-1 text-sm font-medium pt-2">
            <Link
              href="/browse"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-sm text-muted-foreground hover:bg-muted"
            >
              Browse Courses
            </Link>
            {user?.role === 'STUDENT' && (
              <>
                <Link
                  href="/dashboard"
                  onClick={() => setMobileMenuOpen(false)}
                  className="block px-3 py-2 rounded-sm text-muted-foreground hover:bg-muted"
                >
                  My Learning
                </Link>
                <Link
                  href="/wishlist"
                  onClick={() => setMobileMenuOpen(false)}
                  className="block px-3 py-2 rounded-sm text-muted-foreground hover:bg-muted"
                >
                  Wishlist
                </Link>
              </>
            )}
            {user?.role === 'INSTRUCTOR' && (
              <>
                <Link
                  href="/courses"
                  onClick={() => setMobileMenuOpen(false)}
                  className="block px-3 py-2 rounded-sm text-muted-foreground hover:bg-muted"
                >
                  My Courses
                </Link>
                <Link
                  href="/courses/create"
                  onClick={() => setMobileMenuOpen(false)}
                  className="block px-3 py-2 rounded-sm text-primary font-semibold hover:bg-muted"
                >
                  Create Course
                </Link>
              </>
            )}
            {user?.role === 'ADMIN' && (
              <Link
                href="/instructor-applications"
                onClick={() => setMobileMenuOpen(false)}
                className="block px-3 py-2 rounded-sm text-muted-foreground hover:bg-muted"
              >
                Admin Approvals
              </Link>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
