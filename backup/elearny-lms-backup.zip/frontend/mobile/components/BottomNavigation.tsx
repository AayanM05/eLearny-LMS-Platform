import React from 'react';
import { StyleSheet, View, Text, TouchableOpacity } from 'react-native';
import { useRouter, usePathname } from 'expo-router';
import { Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { useAuth } from '../lib/auth';
import { fontInterBold, fontInterSemiBold } from '../lib/typography';

interface TabItem {
  name: string;
  path: string;
  icon: (color: string) => React.ReactNode;
  highlight?: boolean;
}

export default function BottomNavigation() {
  const router = useRouter();
  const pathname = usePathname();
  const { user } = useAuth();

  const isInstructorRoute = pathname?.includes('(instructor)');
  const isAdminRoute = pathname?.includes('(admin)');
  const isStudentRoute = pathname?.includes('(student)');

  const studentTabs: TabItem[] = [
    {
      name: 'Dashboard',
      path: '/(student)/dashboard',
      icon: (color: string) => <Feather name="home" size={20} color={color} />,
    },
    {
      name: 'Practice',
      path: '/(student)/practice',
      icon: (color: string) => <Feather name="code" size={20} color={color} />,
    },
    {
      name: 'AI Tutor',
      path: '/(student)/ai-chat',
      icon: (color: string) => <Feather name="cpu" size={20} color={color} />,
    },
    {
      name: 'Community',
      path: '/(student)/community',
      icon: (color: string) => <Feather name="message-square" size={20} color={color} />,
    },
    {
      name: 'Leaderboard',
      path: '/(student)/leaderboard',
      icon: (color: string) => <MaterialCommunityIcons name="trophy-outline" size={20} color={color} />,
    },
  ];

  const instructorTabs: TabItem[] = [
    {
      name: 'Studio',
      path: '/(instructor)/analytics',
      icon: (color: string) => <Feather name="bar-chart-2" size={20} color={color} />,
    },
    {
      name: 'My Courses',
      path: '/(instructor)/courses',
      icon: (color: string) => <Feather name="book-open" size={20} color={color} />,
    },
    {
      name: 'Create',
      path: '/(instructor)/create-course',
      icon: (color: string) => <Feather name="plus-circle" size={22} color={color} />,
      highlight: true,
    },
    {
      name: 'Student View',
      path: '/(student)/dashboard',
      icon: (color: string) => <Feather name="eye" size={20} color={color} />,
    },
  ];

  const adminTabs: TabItem[] = [
    {
      name: 'Approvals',
      path: '/(admin)/applications',
      icon: (color: string) => <Feather name="shield" size={20} color={color} />,
    },
    {
      name: 'Student View',
      path: '/(student)/dashboard',
      icon: (color: string) => <Feather name="eye" size={20} color={color} />,
    },
  ];

  let currentTabs = studentTabs;
  if (isInstructorRoute || user?.role === 'INSTRUCTOR') {
    currentTabs = instructorTabs;
  } else if (isAdminRoute || user?.role === 'ADMIN') {
    currentTabs = adminTabs;
  } else if (!isStudentRoute && !user) {
    return null;
  }

  return (
    <View style={styles.container}>
      {currentTabs.map((tab) => {
        const isActive = pathname === tab.path || (pathname && pathname.includes(tab.path.split('/').pop() || ''));
        const activeColor = '#7c3aed';
        const inactiveColor = '#94a3b8';

        return (
          <TouchableOpacity
            key={tab.path}
            style={[styles.tabButton, tab.highlight && styles.highlightButton]}
            onPress={() => router.push(tab.path as any)}
            activeOpacity={0.7}
          >
            {tab.icon(isActive ? activeColor : tab.highlight ? '#7c3aed' : inactiveColor)}
            <Text
              style={[
                styles.tabLabel,
                {
                  color: isActive ? activeColor : tab.highlight ? '#7c3aed' : inactiveColor,
                  fontFamily: isActive || tab.highlight ? fontInterBold : fontInterSemiBold,
                },
              ]}
            >
              {tab.name}
            </Text>
            {isActive && <View style={styles.activeDot} />}
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    borderTopWidth: 1,
    borderTopColor: '#f1f5f9',
    paddingVertical: 10,
    paddingHorizontal: 12,
    justifyContent: 'space-around',
    alignItems: 'center',
    shadowColor: '#0f172a',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 12,
  },
  tabButton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 4,
    paddingHorizontal: 8,
    position: 'relative',
  },
  highlightButton: {
    backgroundColor: '#f5f3ff',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  tabLabel: {
    fontSize: 10,
    marginTop: 4,
  },
  activeDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#7c3aed',
    position: 'absolute',
    bottom: -4,
  },
});
