import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Image,
  Modal,
  ActivityIndicator,
  SafeAreaView
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Feather, Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { fontInterRegular, fontInterSemiBold, fontInterBold, fontHeadingDisplay } from '../../../lib/typography';

interface Lesson {
  id: string;
  title: string;
  durationSeconds: number;
  isPreview: boolean;
  dripDelayDays: number;
}

interface Section {
  id: string;
  title: string;
  lessons: Lesson[];
}

export default function MobileCourseDetailPage() {
  const { id } = useLocalSearchParams();
  const router = useRouter();

  const [loading, setLoading] = useState(false);
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({ 'sec-1': true });
  const [activePreviewLesson, setActivePreviewLesson] = useState<Lesson | null>(null);
  const [isWishlisted, setIsWishlisted] = useState(false);

  const course = {
    id: (id as string) || 'demo-1',
    title: 'Master Full-Stack Web Development with Spring Boot 3 & Next.js 14',
    subtitle: 'Build enterprise-grade software platforms with reactive Java backend, Next.js, and Expo mobile.',
    category: 'Software Engineering',
    level: 'INTERMEDIATE',
    price: 49.99,
    thumbnailUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?q=80&w=800',
    instructorName: 'Dr. Sarah Jenkins',
    instructorBio: 'Senior Principal Engineer & Author with 15+ years building distributed backend systems.',
    rating: 4.9,
    studentsCount: 1420,
    sections: [
      {
        id: 'sec-1',
        title: 'Section 1: Monorepo & Baseline Setup',
        lessons: [
          { id: 'les-1', title: 'Course Architecture Overview & Monorepo Setup', durationSeconds: 620, isPreview: true, dripDelayDays: 0 },
          { id: 'les-2', title: 'Spring Boot 3 Dependencies & Flyway Baseline', durationSeconds: 840, isPreview: true, dripDelayDays: 0 },
          { id: 'les-3', title: 'Domain Driven Package Structure & Exception Handler', durationSeconds: 910, isPreview: false, dripDelayDays: 0 },
        ],
      },
      {
        id: 'sec-2',
        title: 'Section 2: Authentication & Security',
        lessons: [
          { id: 'les-4', title: 'JWT Access & Refresh Token Architecture', durationSeconds: 1100, isPreview: false, dripDelayDays: 1 },
          { id: 'les-5', title: 'TOTP 2FA Authentication Implementation', durationSeconds: 780, isPreview: false, dripDelayDays: 2 },
        ],
      },
    ],
  };

  const toggleSection = (sectionId: string) => {
    setOpenSections((prev) => ({ ...prev, [sectionId]: !prev[sectionId] }));
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    return `${mins}m`;
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Header Bar */}
        <View style={styles.topHeader}>
          <TouchableOpacity onPress={() => router.back()} style={styles.iconButton}>
            <Feather name="arrow-left" size={20} color="#0f172a" />
          </TouchableOpacity>
          <Text style={styles.topHeaderTitle} numberOfLines={1}>Course Details</Text>
          <TouchableOpacity onPress={() => setIsWishlisted(!isWishlisted)} style={styles.iconButton}>
            <Ionicons
              name={isWishlisted ? 'bookmark' : 'bookmark-outline'}
              size={20}
              color={isWishlisted ? '#7c3aed' : '#0f172a'}
            />
          </TouchableOpacity>
        </View>

        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          {/* Hero Thumbnail */}
          <View style={styles.thumbnailContainer}>
            <Image source={{ uri: course.thumbnailUrl }} style={styles.thumbnailImage} />
            <TouchableOpacity
              style={styles.playOverlayButton}
              onPress={() => setActivePreviewLesson(course.sections[0].lessons[0])}
            >
              <Feather name="play-circle" size={44} color="#7c3aed" />
            </TouchableOpacity>
          </View>

          {/* Title & Metadata */}
          <View style={styles.infoSection}>
            <View style={styles.categoryBadge}>
              <Text style={styles.categoryBadgeText}>{course.category}</Text>
            </View>

            <Text style={styles.courseTitle}>{course.title}</Text>
            <Text style={styles.courseSubtitle}>{course.subtitle}</Text>

            {/* Badges Row */}
            <View style={styles.metaRow}>
              <View style={styles.metaItem}>
                <Ionicons name="star" size={14} color="#f59e0b" />
                <Text style={styles.metaTextBold}>{course.rating}</Text>
                <Text style={styles.metaTextMuted}>(128)</Text>
              </View>
              <View style={styles.metaItem}>
                <Feather name="users" size={14} color="#7c3aed" />
                <Text style={styles.metaTextMuted}>{course.studentsCount} students</Text>
              </View>
              <View style={styles.metaItem}>
                <Feather name="award" size={14} color="#10b981" />
                <Text style={styles.metaTextMuted}>{course.level}</Text>
              </View>
            </View>

            {/* Instructor Info */}
            <View style={styles.instructorCard}>
              <View style={styles.instructorAvatar}>
                <Text style={styles.avatarText}>{course.instructorName[0]}</Text>
              </View>
              <View style={styles.instructorTextGroup}>
                <Text style={styles.instructorName}>{course.instructorName}</Text>
                <Text style={styles.instructorBio}>{course.instructorBio}</Text>
              </View>
            </View>

            {/* Curriculum Accordion */}
            <View style={styles.curriculumSection}>
              <Text style={styles.sectionHeaderTitle}>Course Curriculum</Text>

              {course.sections.map((sec) => {
                const isOpen = openSections[sec.id];
                return (
                  <View key={sec.id} style={styles.accordionBox}>
                    <TouchableOpacity
                      onPress={() => toggleSection(sec.id)}
                      style={styles.accordionHeader}
                      activeOpacity={0.7}
                    >
                      <Text style={styles.accordionTitle}>{sec.title}</Text>
                      <Feather name={isOpen ? 'chevron-down' : 'chevron-right'} size={18} color="#64748b" />
                    </TouchableOpacity>

                    {isOpen && (
                      <View style={styles.accordionContent}>
                        {sec.lessons.map((les) => (
                          <View key={les.id} style={styles.lessonRow}>
                            <View style={styles.lessonTitleGroup}>
                              <Feather name="video" size={14} color="#64748b" />
                              <Text style={styles.lessonTitleText}>{les.title}</Text>
                            </View>
                            <View style={styles.lessonRightGroup}>
                              {les.isPreview && (
                                <TouchableOpacity
                                  onPress={() => setActivePreviewLesson(les)}
                                  style={styles.previewTag}
                                >
                                  <Text style={styles.previewTagText}>Preview</Text>
                                </TouchableOpacity>
                              )}
                              <Text style={styles.lessonDurationText}>{formatDuration(les.durationSeconds)}</Text>
                            </View>
                          </View>
                        ))}
                      </View>
                    )}
                  </View>
                );
              })}
            </View>
          </View>
        </ScrollView>

        {/* Sticky Bottom Bar */}
        <View style={styles.bottomBar}>
          <View>
            <Text style={styles.priceText}>${course.price.toFixed(2)}</Text>
            <Text style={styles.guaranteeText}>30-day money-back</Text>
          </View>
          <TouchableOpacity
            style={styles.enrollButton}
            onPress={() => router.push('/(student)/dashboard')}
          >
            <Text style={styles.enrollButtonText}>Enroll Now</Text>
          </TouchableOpacity>
        </View>

        {/* Free Preview Modal */}
        {activePreviewLesson && (
          <Modal visible transparent animationType="fade">
            <View style={styles.modalOverlay}>
              <View style={styles.modalCard}>
                <View style={styles.modalHeader}>
                  <Text style={styles.modalTitle}>Free Sample Preview</Text>
                  <TouchableOpacity onPress={() => setActivePreviewLesson(null)}>
                    <Feather name="x" size={20} color="#0f172a" />
                  </TouchableOpacity>
                </View>
                <View style={styles.videoPlaceholder}>
                  <Feather name="play-circle" size={48} color="#7c3aed" />
                  <Text style={styles.previewLessonName}>{activePreviewLesson.title}</Text>
                </View>
                <TouchableOpacity
                  style={styles.modalEnrollButton}
                  onPress={() => {
                    setActivePreviewLesson(null);
                    router.push('/(student)/dashboard');
                  }}
                >
                  <Text style={styles.enrollButtonText}>Enroll to Access Full Course</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  topHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
    backgroundColor: '#ffffff',
  },
  topHeaderTitle: {
    fontSize: 16,
    fontFamily: fontHeadingDisplay,
    color: '#0f172a',
    flex: 1,
    textAlign: 'center',
    marginHorizontal: 8,
  },
  iconButton: {
    padding: 6,
  },
  scrollContent: {
    paddingBottom: 24,
  },
  thumbnailContainer: {
    height: 200,
    width: '100%',
    backgroundColor: '#0f172a',
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  thumbnailImage: {
    width: '100%',
    height: '100%',
    opacity: 0.8,
  },
  playOverlayButton: {
    position: 'absolute',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 30,
    padding: 4,
  },
  infoSection: {
    padding: 16,
  },
  categoryBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#f5f3ff',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    marginBottom: 8,
  },
  categoryBadgeText: {
    fontSize: 11,
    fontFamily: fontInterSemiBold,
    color: '#7c3aed',
    textTransform: 'uppercase',
  },
  courseTitle: {
    fontSize: 20,
    fontFamily: fontHeadingDisplay,
    color: '#0f172a',
    marginBottom: 6,
    lineHeight: 26,
  },
  courseSubtitle: {
    fontSize: 13,
    fontFamily: fontInterRegular,
    color: '#475569',
    lineHeight: 18,
    marginBottom: 12,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaTextBold: {
    fontSize: 12,
    fontFamily: fontInterBold,
    color: '#0f172a',
  },
  metaTextMuted: {
    fontSize: 12,
    fontFamily: fontInterRegular,
    color: '#64748b',
  },
  instructorCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  instructorAvatar: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: '#f5f3ff',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    fontSize: 16,
    fontFamily: fontInterBold,
    color: '#7c3aed',
  },
  instructorTextGroup: {
    flex: 1,
  },
  instructorName: {
    fontSize: 14,
    fontFamily: fontInterBold,
    color: '#0f172a',
  },
  instructorBio: {
    fontSize: 11,
    fontFamily: fontInterRegular,
    color: '#64748b',
  },
  curriculumSection: {
    marginTop: 16,
  },
  sectionHeaderTitle: {
    fontSize: 16,
    fontFamily: fontHeadingDisplay,
    color: '#0f172a',
    marginBottom: 12,
  },
  accordionBox: {
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 6,
    marginBottom: 8,
    overflow: 'hidden',
  },
  accordionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 12,
    backgroundColor: '#f8fafc',
  },
  accordionTitle: {
    fontSize: 13,
    fontFamily: fontInterSemiBold,
    color: '#0f172a',
    flex: 1,
    marginRight: 8,
  },
  accordionContent: {
    backgroundColor: '#ffffff',
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  lessonRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  lessonTitleGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
  },
  lessonTitleText: {
    fontSize: 12,
    fontFamily: fontInterRegular,
    color: '#334155',
    flex: 1,
  },
  lessonRightGroup: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  previewTag: {
    backgroundColor: '#f5f3ff',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  previewTagText: {
    fontSize: 10,
    fontFamily: fontInterSemiBold,
    color: '#7c3aed',
  },
  lessonDurationText: {
    fontSize: 11,
    fontFamily: fontInterRegular,
    color: '#94a3b8',
  },
  bottomBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
    backgroundColor: '#ffffff',
  },
  priceText: {
    fontSize: 20,
    fontFamily: fontHeadingDisplay,
    color: '#0f172a',
  },
  guaranteeText: {
    fontSize: 10,
    fontFamily: fontInterRegular,
    color: '#64748b',
  },
  enrollButton: {
    backgroundColor: '#7c3aed',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 6,
  },
  enrollButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontFamily: fontInterBold,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(15, 23, 42, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  modalCard: {
    width: '100%',
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 16,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  modalTitle: {
    fontSize: 15,
    fontFamily: fontHeadingDisplay,
    color: '#0f172a',
  },
  videoPlaceholder: {
    height: 180,
    backgroundColor: '#0f172a',
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  previewLessonName: {
    color: '#ffffff',
    fontSize: 13,
    fontFamily: fontInterSemiBold,
    textAlign: 'center',
    paddingHorizontal: 12,
  },
  modalEnrollButton: {
    backgroundColor: '#7c3aed',
    paddingVertical: 12,
    borderRadius: 6,
    alignItems: 'center',
  },
});
